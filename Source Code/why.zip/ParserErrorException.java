public class ParserErrorException extends Exception{

    public ParserErrorException(String message){
        super(message);
    }
}
