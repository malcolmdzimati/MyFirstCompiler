This is eg1:
It shows you how to run the compiler with the input file being in the same directory

The jar file is the same jar file across all files.

Run using:
make
or 
make run

Enter Filename:
test1.txt

Result:
The XML file will be stored in this directory
